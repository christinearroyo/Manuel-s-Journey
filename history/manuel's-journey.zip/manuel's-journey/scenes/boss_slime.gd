extends Area2D

@onready var timer = $Timer

const SPEED = 60

var direction = 1
@onready var collision_shape_2d: CollisionShape2D = $CollisionShape2D
@onready var ray_cast_right = $RayCastRight
@onready var ray_cast_left = $RayCastLeft
@onready var animated_sprite = $AnimatedSprite2D
func _ready() -> void:
	collision_shape_2d.disabled = true
var hit = false
func _process(delta: float) -> void:
	if ray_cast_right.is_colliding():
		direction = 1
		animated_sprite.flip_h = false
	if ray_cast_left.is_colliding():
		direction = -1
		animated_sprite.flip_h = true
	position.x += direction * SPEED * delta
	if animated_sprite.frame % 4 == 0 and !hit:
		collision_shape_2d.disabled = false
		hit = true
	else :
		collision_shape_2d.disabled = true
		print(animated_sprite.frame)
		
func _on_body_entered(body: Node2D) -> void:
	print("You Died")
	Engine.time_scale = 0.5
	body.get_node("CollisionShape2D").queue_free()
	timer.start()
	
func _on_timer_timeout() -> void:
	Engine.time_scale = 1.0
	get_tree().reload_current_scene()
	
