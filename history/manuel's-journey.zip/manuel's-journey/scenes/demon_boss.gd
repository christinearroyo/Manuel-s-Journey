extends Area2D

@export var speed = 100
@export var move_distance = 250

var direction = 1
var start_x: float = 0.0

func _ready():
	start_x = position.x

func _process(delta):
	position.x += speed * direction * delta

	if position.x > start_x + move_distance:
		direction = -1

	if position.x < start_x:
		direction = 1
