extends Area2D

@onready var timer = $Timer

const SPEED = 60

var direction = -1
@onready var collision_shape_2d: CollisionShape2D = $CollisionShape2D
@onready var ray_cast_right = $RayCastRight
@onready var ray_cast_left = $RayCastLeft
@onready var animated_sprite = $AnimatedSprite2D
# Called every frame. 'delta' is the elapsed time since the previous frame.
func _ready() -> void:
	collision_shape_2d.disabled = true
var hit = false
func _process(delta: float) -> void:
	if ray_cast_right.is_colliding():
		direction = -1
		animated_sprite.flip_h = false
		collision_shape_2d.position.x -= 93
		collision_shape_2d.rotation = deg_to_rad(20.0)
	if ray_cast_left.is_colliding():
		direction = 1
		animated_sprite.flip_h = true
		collision_shape_2d.position.x += 93
		collision_shape_2d.rotation = deg_to_rad(-20.0)
	position.x += direction * SPEED * delta
	collision_shape_2d.position.x += direction * delta
	if animated_sprite.frame == 27 and !hit:
		collision_shape_2d.disabled = false
		hit = true
	if animated_sprite.frame == 28:
		collision_shape_2d.disabled = true
		hit = false
func _on_body_entered(body: Node2D) -> void:
	print("You Died")
	Engine.time_scale = 0.5
	body.get_node("CollisionShape2D").queue_free()
	timer.start()
	
func _on_timer_timeout() -> void:
	Engine.time_scale = 1.0
	get_tree().reload_current_scene()
	
